# Project Web TDTU

## Technologies

-   Node.js

## Personal information

-   Ho&Ten: Lê Thanh Tùng; MSSV: 51800830
-   Ho&Ten: Hoàng Thị Thùy Trang; MSSV: 51900249
-   Ho&Ten: Võ Minh Thuận; MSSV: 51900838
-   Ho&Ten: Trần Bình Trọng; MSSV: 51800253

## How to configure & run

-   Bước 1: npm i
-   Bước 2: npm run start
-   http://localhost:3000/
